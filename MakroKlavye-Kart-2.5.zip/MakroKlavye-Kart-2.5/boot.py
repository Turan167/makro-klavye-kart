import board
import digitalio
import storage

# boot.py yalnızca kart USB'ye takılınca (ya da RESET'te) çalışır.
# Kart yazılımı güncellemesiyle gelir; hata verse bile kart açılsın diye her adım ayrı korunur.

# --- USB'de görünen ad: Windows'ta "Makro Klavye" yazar (kart 2.3+) ---
# Değişiklik klavye çıkarılıp yeniden takılınca görünür.
try:
    import supervisor
    supervisor.set_usb_identification(manufacturer="Makro Klavye", product="Makro Klavye")
except Exception:
    pass   # eski CircuitPython'da yok: varsayılan ad kalır

# --- Dosya sistemi ---
# Kod settings.txt'ye yazabilsin diye dosya sistemini kod tarafına açar.
# Bu durumda PC'de CIRCUITPY sürücüsü SALT OKUNUR görünür.
#
# Kod dosyalarını PC'den elle kopyalamak istediğinde klavyeyi
# encoder'ın altındaki 9 numaralı tuşa (GP29) BASILI TUTARAK USB'ye tak:
# bu durumda sürücü PC'ye yazılabilir kalır.
try:
    tus = digitalio.DigitalInOut(board.GP29)
    tus.switch_to_input(pull=digitalio.Pull.UP)
    if tus.value:          # tuşa basılı değil
        storage.remount("/", readonly=False)
    tus.deinit()
except Exception as e:
    print("boot.py:", e)
