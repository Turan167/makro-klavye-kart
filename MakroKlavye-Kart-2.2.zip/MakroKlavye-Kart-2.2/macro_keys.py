"""
macro_keys.py - CircuitPython HID makro kütüphanesi

Kullanım:
    from macro_keys import MacroKeys, load_settings

    macros = MacroKeys()
    macros.run("CTRL+ALT+S")          # klavye kısayolu
    macros.run("MEDIA_PLAY_PAUSE")    # medya tuşu
    macros.run("DISPLAY")             # Windows+P (ekran değiştirme)
    macros.run("TEXT:Merhaba dünya")  # metin yazdır (US düzeni)
    macros.run("TEXT:sifre{ENTER}")   # yazıdan sonra Enter'a bas
    macros.duzen = "TR"               # bilgisayar Türkçe Q klavye kullanıyorsa (ç ş ğ ü ö ı yazılır)
    macros.volume_up()
    macros.run("SCROLL_DOWN")         # fare tekerleği (1 çentik)
    macros.run("SCROLL_DOWN:5")       # fare tekerleği 5 çentik

    while True:
        macros.update()               # Windows tuşunu zamanı gelince bırakır
"""

import time
import usb_hid

from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

# Fare (tekerlek ve tıklama). adafruit_hid/mouse.mpy yoksa fare komutları sessizce devre dışı kalır.
try:
    from adafruit_hid.mouse import Mouse
except ImportError:
    Mouse = None


# ---------------------------------------------------------
# Tuş isimleri (settings.txt'de yazılabilecek isimler)
# keycode.mpy içindeki tüm tuşlar + kısa takma adlar
# ---------------------------------------------------------

KEY_ALIASES = {
    # --- Harfler ---
    "A": Keycode.A, "B": Keycode.B, "C": Keycode.C, "D": Keycode.D,
    "E": Keycode.E, "F": Keycode.F, "G": Keycode.G, "H": Keycode.H,
    "I": Keycode.I, "J": Keycode.J, "K": Keycode.K, "L": Keycode.L,
    "M": Keycode.M, "N": Keycode.N, "O": Keycode.O, "P": Keycode.P,
    "Q": Keycode.Q, "R": Keycode.R, "S": Keycode.S, "T": Keycode.T,
    "U": Keycode.U, "V": Keycode.V, "W": Keycode.W, "X": Keycode.X,
    "Y": Keycode.Y, "Z": Keycode.Z,

    # --- Rakamlar ---
    "ONE": Keycode.ONE, "TWO": Keycode.TWO, "THREE": Keycode.THREE,
    "FOUR": Keycode.FOUR, "FIVE": Keycode.FIVE, "SIX": Keycode.SIX,
    "SEVEN": Keycode.SEVEN, "EIGHT": Keycode.EIGHT, "NINE": Keycode.NINE,
    "ZERO": Keycode.ZERO,
    "1": Keycode.ONE, "2": Keycode.TWO, "3": Keycode.THREE,
    "4": Keycode.FOUR, "5": Keycode.FIVE, "6": Keycode.SIX,
    "7": Keycode.SEVEN, "8": Keycode.EIGHT, "9": Keycode.NINE,
    "0": Keycode.ZERO,

    # --- Fonksiyon tuşları ---
    "F1": Keycode.F1, "F2": Keycode.F2, "F3": Keycode.F3,
    "F4": Keycode.F4, "F5": Keycode.F5, "F6": Keycode.F6,
    "F7": Keycode.F7, "F8": Keycode.F8, "F9": Keycode.F9,
    "F10": Keycode.F10, "F11": Keycode.F11, "F12": Keycode.F12,
    "F13": Keycode.F13, "F14": Keycode.F14, "F15": Keycode.F15,
    "F16": Keycode.F16, "F17": Keycode.F17, "F18": Keycode.F18,
    "F19": Keycode.F19, "F20": Keycode.F20, "F21": Keycode.F21,
    "F22": Keycode.F22, "F23": Keycode.F23, "F24": Keycode.F24,

    # --- Düzenleme / genel ---
    "ENTER": Keycode.ENTER,
    "RETURN": Keycode.RETURN,
    "ESCAPE": Keycode.ESCAPE,
    "ESC": Keycode.ESCAPE,
    "BACKSPACE": Keycode.BACKSPACE,
    "BKSP": Keycode.BACKSPACE,
    "TAB": Keycode.TAB,
    "SPACEBAR": Keycode.SPACEBAR,
    "SPACE": Keycode.SPACE,
    "DELETE": Keycode.DELETE,
    "DEL": Keycode.DELETE,
    "INSERT": Keycode.INSERT,
    "HOME": Keycode.HOME,
    "END": Keycode.END,
    "PAGE_UP": Keycode.PAGE_UP,
    "PGUP": Keycode.PAGE_UP,
    "PAGE_DOWN": Keycode.PAGE_DOWN,
    "PGDN": Keycode.PAGE_DOWN,
    "CAPS_LOCK": Keycode.CAPS_LOCK,
    "CAPS": Keycode.CAPS_LOCK,
    "PRINT_SCREEN": Keycode.PRINT_SCREEN,
    "PRTSC": Keycode.PRINT_SCREEN,
    "SCROLL_LOCK": Keycode.SCROLL_LOCK,
    "PAUSE": Keycode.PAUSE,
    "APPLICATION": Keycode.APPLICATION,
    "MENU": Keycode.APPLICATION,
    "POWER": Keycode.POWER,

    # --- Oklar ---
    "UP_ARROW": Keycode.UP_ARROW,
    "DOWN_ARROW": Keycode.DOWN_ARROW,
    "LEFT_ARROW": Keycode.LEFT_ARROW,
    "RIGHT_ARROW": Keycode.RIGHT_ARROW,
    "UP": Keycode.UP_ARROW,
    "DOWN": Keycode.DOWN_ARROW,
    "LEFT": Keycode.LEFT_ARROW,
    "RIGHT": Keycode.RIGHT_ARROW,

    # --- Noktalama ---
    "MINUS": Keycode.MINUS,
    "EQUALS": Keycode.EQUALS,
    "LEFT_BRACKET": Keycode.LEFT_BRACKET,
    "RIGHT_BRACKET": Keycode.RIGHT_BRACKET,
    "BACKSLASH": Keycode.BACKSLASH,
    "POUND": Keycode.POUND,
    "SEMICOLON": Keycode.SEMICOLON,
    "QUOTE": Keycode.QUOTE,
    "GRAVE_ACCENT": Keycode.GRAVE_ACCENT,
    "COMMA": Keycode.COMMA,
    "PERIOD": Keycode.PERIOD,
    "FORWARD_SLASH": Keycode.FORWARD_SLASH,

    # --- Sayısal tuş takımı ---
    "KEYPAD_NUMLOCK": Keycode.KEYPAD_NUMLOCK,
    "KEYPAD_FORWARD_SLASH": Keycode.KEYPAD_FORWARD_SLASH,
    "KEYPAD_ASTERISK": Keycode.KEYPAD_ASTERISK,
    "KEYPAD_MINUS": Keycode.KEYPAD_MINUS,
    "KEYPAD_PLUS": Keycode.KEYPAD_PLUS,
    "KEYPAD_ENTER": Keycode.KEYPAD_ENTER,
    "KEYPAD_ONE": Keycode.KEYPAD_ONE,
    "KEYPAD_TWO": Keycode.KEYPAD_TWO,
    "KEYPAD_THREE": Keycode.KEYPAD_THREE,
    "KEYPAD_FOUR": Keycode.KEYPAD_FOUR,
    "KEYPAD_FIVE": Keycode.KEYPAD_FIVE,
    "KEYPAD_SIX": Keycode.KEYPAD_SIX,
    "KEYPAD_SEVEN": Keycode.KEYPAD_SEVEN,
    "KEYPAD_EIGHT": Keycode.KEYPAD_EIGHT,
    "KEYPAD_NINE": Keycode.KEYPAD_NINE,
    "KEYPAD_ZERO": Keycode.KEYPAD_ZERO,
    "KEYPAD_PERIOD": Keycode.KEYPAD_PERIOD,
    "KEYPAD_BACKSLASH": Keycode.KEYPAD_BACKSLASH,
    "KEYPAD_EQUALS": Keycode.KEYPAD_EQUALS,

    # --- Değiştirici (modifier) tuşlar ---
    "CONTROL": Keycode.CONTROL,
    "CTRL": Keycode.CONTROL,
    "LEFT_CONTROL": Keycode.LEFT_CONTROL,
    "RIGHT_CONTROL": Keycode.RIGHT_CONTROL,
    "SHIFT": Keycode.SHIFT,
    "LEFT_SHIFT": Keycode.LEFT_SHIFT,
    "RIGHT_SHIFT": Keycode.RIGHT_SHIFT,
    "ALT": Keycode.ALT,
    "LEFT_ALT": Keycode.LEFT_ALT,
    "RIGHT_ALT": Keycode.RIGHT_ALT,
    "OPTION": Keycode.OPTION,
    "GUI": Keycode.GUI,
    "LEFT_GUI": Keycode.LEFT_GUI,
    "RIGHT_GUI": Keycode.RIGHT_GUI,
    "WINDOWS": Keycode.WINDOWS,
    "WIN": Keycode.WINDOWS,
    "COMMAND": Keycode.COMMAND,
}

# Medya komutları
CONSUMER_COMMANDS = {
    "MEDIA_PREVIOUS": ConsumerControlCode.SCAN_PREVIOUS_TRACK,
    "MEDIA_NEXT": ConsumerControlCode.SCAN_NEXT_TRACK,
    "MEDIA_PLAY_PAUSE": ConsumerControlCode.PLAY_PAUSE,
    "MUTE": ConsumerControlCode.MUTE,
    "VOLUME_UP": ConsumerControlCode.VOLUME_INCREMENT,
    "VOLUME_DOWN": ConsumerControlCode.VOLUME_DECREMENT,
    # Özel klavye tuşları (HID Consumer kodları; adafruit_hid'de adı olmayanlar sayı olarak)
    "MEDIA_STOP": 0xB7,
    "MEDIA_FAST_FORWARD": 0xB3,
    "MEDIA_REWIND": 0xB4,
    "BRIGHTNESS_UP": 0x6F,     # ekran parlaklığı (çoğunlukla dizüstünde çalışır)
    "BRIGHTNESS_DOWN": 0x70,
    "CALCULATOR": 0x192,
    "EMAIL": 0x18A,
    "MY_COMPUTER": 0x194,      # Bu bilgisayar / Dosya Gezgini
    "BROWSER_HOME": 0x223,     # varsayılan tarayıcı
}


# ---------------------------------------------------------
# Türkçe Q klavye düzeni (Windows). Kaynak: Neradoc/Circuitpython_Keyboard_Layouts
# (keyboard_layout_win_tr.py, MIT lisansı). Bir değer: tuş kodu, 0x80 biti = Shift.
# TR_ALTGR'deki karakterler sağ Alt (AltGr) ile basılır. 0 = bu düzende yazılamaz (^ ` ~).
# ---------------------------------------------------------
TR_ASCII = (
    b'\x00\x00\x00\x00\x00\x00\x00\x00*+(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    b'\x00\x00\x00\x00\x00)\x00\x00\x00\x00,\x9e5 !\xa2\xa3\x9f\xa5\xa6-\xa11.8\xa4\'\x1e\x1f'
    b' !"#$%&\xb8\xb15\xa7\x1e\xad\x14\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f'
    b'\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d%-&\x00\xae\x00\x04\x05'
    b'\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b'
    b'\x1c\x1d$.\'\x00\x00'
)
TR_ALTGR = "#$<>@[\\]i{|}£½€₺"
TR_YUKSEK = {
    "ı": 0x0C, "İ": 0xB4, "ğ": 0x2F, "Ğ": 0xAF, "ü": 0x30, "Ü": 0xB0,
    "ş": 0x33, "Ş": 0xB3, "ö": 0x36, "Ö": 0xB6, "ç": 0x37, "Ç": 0xB7,
    "é": 0xB5, "£": 0x1F, "½": 0x22, "€": 0x08, "₺": 0x17,
}


def tr_tuslari(ch):
    """Türkçe Q düzeninde bir karakter için basılacak tuşlar; yazılamıyorsa None."""
    o = ord(ch)
    if o < 128:
        kod = TR_ASCII[o]
    else:
        kod = TR_YUKSEK.get(ch, 0)
    if not kod:
        return None
    tuslar = []
    if kod & 0x80:
        tuslar.append(Keycode.SHIFT)
    if ch in TR_ALTGR:
        tuslar.append(Keycode.RIGHT_ALT)
    tuslar.append(kod & 0x7F)
    return tuslar


def split_text_macro(text, gecerli_mi):
    """
    'sifre{TAB}ab{ENTER}' -> [("text","sifre"), ("key","TAB"), ("text","ab"), ("key","ENTER")]
    Geçerli olmayan {...} parçaları düz yazı olarak kalır.
    """
    parcalar = []
    tampon = ""
    i = 0
    n = len(text)

    while i < n:
        c = text[i]
        if c == "{":
            j = text.find("}", i + 1)
            if j > i + 1 and gecerli_mi(text[i + 1:j]):
                if tampon:
                    parcalar.append(("text", tampon))
                    tampon = ""
                parcalar.append(("key", text[i + 1:j]))
                i = j + 1
                continue
        tampon += c
        i += 1

    if tampon:
        parcalar.append(("text", tampon))
    return parcalar

# Fare komutları: encoder ile kaydırma / yakınlaştırma için idealdir
MOUSE_COMMANDS = (
    "SCROLL_UP",     # tekerlek yukarı
    "SCROLL_DOWN",   # tekerlek aşağı
    "ZOOM_IN",       # Ctrl + tekerlek yukarı
    "ZOOM_OUT",      # Ctrl + tekerlek aşağı
    "MOUSE_LEFT",    # sol tık
    "MOUSE_RIGHT",   # sağ tık
    "MOUSE_MIDDLE",  # orta tık
)


def split_macro(metin):
    """
    Makro gövdesini adımlara ayırır. Adımlar | ile ayrılır;
    yazının içindeki | ve \\ karakterleri \\| ve \\\\ olarak kaçırılmıştır.
        'CTRL+C|WAIT:200|ALT+TAB|TEXT:a\\|b' -> ['CTRL+C', 'WAIT:200', 'ALT+TAB', 'TEXT:a|b']
    """
    adimlar = []
    tampon = ""
    i = 0
    n = len(metin)

    while i < n:
        c = metin[i]
        if c == "\\" and i + 1 < n:
            tampon += metin[i + 1]
            i += 2
        elif c == "|":
            adimlar.append(tampon)
            tampon = ""
            i += 1
        else:
            tampon += c
            i += 1

    adimlar.append(tampon)
    return [a for a in adimlar if a]


# ---------------------------------------------------------
# settings.txt okuma
# ---------------------------------------------------------

def load_settings(path="/settings.txt", defaults=None):
    """
    KEY=VALUE satırlarını okur. Boş satırlar ve # ile başlayanlar atlanır.
    Dosyada olmayan ayarlar için `defaults` değerleri kullanılır.
    """
    settings = dict(defaults) if defaults else {}

    try:
        with open(path, "r") as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                settings[key.strip()] = value.strip()
        print(path, "okundu.")
    except Exception as e:
        print(path, "okunamadı, varsayılanlar kullanılıyor:", e)

    return settings


# ---------------------------------------------------------
# Ana sınıf
# ---------------------------------------------------------

class MacroKeys:
    def __init__(self, devices=None, win_p_timeout=1.4):
        """
        devices       : usb_hid.devices (verilmezse otomatik alınır)
        win_p_timeout : Windows+P menüsünde son basıştan sonra
                        Windows tuşunun ne kadar süre basılı tutulacağı (sn)
        """
        devices = devices or usb_hid.devices
        self.keyboard = Keyboard(devices)
        self.layout = KeyboardLayoutUS(self.keyboard)
        self.consumer = ConsumerControl(devices)

        self.mouse = None
        if Mouse is not None:
            try:
                self.mouse = Mouse(devices)
            except Exception as e:
                print("Fare başlatılamadı:", e)

        self.win_p_timeout = win_p_timeout
        self.duzen = "US"                 # "US" ya da "TR" (bilgisayardaki Windows klavye düzeni)
        self.harf_bekleme = 0             # sn: metin yazarken harfler arası bekleme (0 = en hızlı)
        self._winp_open = False
        self._winp_last = 0

    # -----------------------------------------------------
    # Komut çalıştırma
    # -----------------------------------------------------

    def run(self, command):
        """
        Komutu çalıştırır. Tanınırsa True, tanınmazsa False döner.
        (PIXEL_MODE gibi kütüphane dışı komutları ana kod ele alır.)
        """
        if command.startswith("TEXT:"):
            return self.type_text(command[5:])

        if command in CONSUMER_COMMANDS:
            self.consumer.send(CONSUMER_COMMANDS[command])
            return True

        if command == "DISPLAY":
            self._display_switch()
            return True

        if command in MOUSE_COMMANDS:
            return self.mouse_command(command)

        if command.startswith("SCROLL_UP:") or command.startswith("SCROLL_DOWN:"):
            return self.scroll(command)

        return self.send_combo(command)

    # -----------------------------------------------------
    # Fare
    # -----------------------------------------------------

    def mouse_command(self, command):
        if self.mouse is None:
            print("Fare desteği yok (adafruit_hid/mouse.mpy eksik olabilir)")
            return False

        if command == "SCROLL_UP":
            self.mouse.move(wheel=1)
        elif command == "SCROLL_DOWN":
            self.mouse.move(wheel=-1)
        elif command in ("ZOOM_IN", "ZOOM_OUT"):
            self.keyboard.press(Keycode.CONTROL)
            self.mouse.move(wheel=1 if command == "ZOOM_IN" else -1)
            self.keyboard.release(Keycode.CONTROL)
        elif command == "MOUSE_LEFT":
            self.mouse.click(Mouse.LEFT_BUTTON)
        elif command == "MOUSE_RIGHT":
            self.mouse.click(Mouse.RIGHT_BUTTON)
        elif command == "MOUSE_MIDDLE":
            self.mouse.click(Mouse.MIDDLE_BUTTON)
        return True

    def scroll(self, command):
        """'SCROLL_DOWN:5' -> tekerleği 5 çentik aşağı (1-50)."""
        if self.mouse is None:
            print("Fare desteği yok (adafruit_hid/mouse.mpy eksik olabilir)")
            return False
        ad, _, sayi = command.partition(":")
        try:
            n = max(1, min(50, int(sayi)))
        except ValueError:
            n = 1
        self.mouse.move(wheel=n if ad == "SCROLL_UP" else -n)
        return True

    def send_combo(self, command):
        """'CTRL+ALT+S' gibi bir kombinasyonu gönderir."""
        keys = []

        for part in command.split("+"):
            keycode = self.find_key(part.strip())
            if keycode is None:
                print("Bilinmeyen tuş:", part)
                return False
            keys.append(keycode)

        if keys:
            self.keyboard.send(*keys)
            return True
        return False

    # -----------------------------------------------------
    # Tuş arama / yardımcılar (keycode.mpy)
    # -----------------------------------------------------

    @staticmethod
    def find_key(name):
        """İsimden keycode bulur; yoksa None. Önce KEY_ALIASES, sonra Keycode."""
        name = name.strip().upper()
        if name in KEY_ALIASES:
            return KEY_ALIASES[name]
        return getattr(Keycode, name, None)

    @staticmethod
    def is_modifier(keycode):
        """Ctrl/Shift/Alt/GUI gibi bir değiştirici tuşsa True."""
        return Keycode.modifier_bit(keycode) != 0

    @staticmethod
    def key_names():
        """Kullanılabilen tüm tuş isimlerini döndürür (sıralı)."""
        return sorted(KEY_ALIASES.keys())

    # -----------------------------------------------------
    # Metin yazma (keyboard_layout_us.mpy)
    # -----------------------------------------------------

    def type_text(self, text):
        """
        Metni US klavye düzenine göre yazar.
        Süslü parantez içindeki tuşlara basar: "sifre{TAB}parola{ENTER}"
        {ENTER}, {TAB}, {ESC}, {CTRL+A} gibi geçerli tuş/kombinasyon adları kullanılabilir.
        """
        try:
            for tur, deger in split_text_macro(text, self._combo_gecerli):
                if tur != "text":
                    self.send_combo(deger)
                elif self.duzen == "TR":
                    self._yaz_tr(deger)
                elif self.harf_bekleme:
                    for ch in deger:              # yavaş yazma: harf harf
                        self.layout.write(ch)
                        time.sleep(self.harf_bekleme)
                else:
                    self.layout.write(deger)
            return True
        except Exception as e:
            print("Metin yazılamadı:", e)
            return False

    def _yaz_tr(self, metin):
        """Türkçe Q düzeninde yazar; düzende olmayan karakter atlanır."""
        for ch in metin:
            tuslar = tr_tuslari(ch)
            if tuslar is None:
                print("Türkçe düzende yazılamıyor:", ch)
                continue
            self.keyboard.send(*tuslar)
            if self.harf_bekleme:
                time.sleep(self.harf_bekleme)

    def _combo_gecerli(self, ad):
        """'ENTER' ya da 'CTRL+A' gibi bir ad tamamen bilinen tuşlardan mı oluşuyor?"""
        for parca in ad.split("+"):
            if self.find_key(parca) is None:
                return False
        return True

    def keycodes_for(self, char):
        """Bir karakter için gereken keycode'ları döndürür (örn. 'A' -> SHIFT, A)."""
        return self.layout.keycodes(char)

    # -----------------------------------------------------
    # Ses
    # -----------------------------------------------------

    def volume_up(self):
        self.consumer.send(ConsumerControlCode.VOLUME_INCREMENT)

    def volume_down(self):
        self.consumer.send(ConsumerControlCode.VOLUME_DECREMENT)

    # -----------------------------------------------------
    # Windows + P (ekran değiştirme)
    # -----------------------------------------------------

    def _display_switch(self):
        now = time.monotonic()

        if not self._winp_open:
            # İlk basış: Windows basılı kalır, menü açılır
            self.keyboard.press(Keycode.WINDOWS)
            self.keyboard.press(Keycode.P)
            self.keyboard.release(Keycode.P)
            self._winp_open = True
            time.sleep(0.3)
        else:
            # Menü açıkken P'ye tekrar basınca sonraki seçeneğe geçer
            self.keyboard.press(Keycode.P)
            self.keyboard.release(Keycode.P)
            time.sleep(0.1)

        self._winp_last = now

    def update(self):
        """Ana döngüde sürekli çağır: süre dolunca Windows tuşunu bırakır."""
        if self._winp_open and (
            time.monotonic() - self._winp_last >= self.win_p_timeout
        ):
            self.keyboard.release(Keycode.WINDOWS)
            self._winp_open = False
