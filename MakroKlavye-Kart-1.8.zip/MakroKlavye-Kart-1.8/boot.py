import board
import digitalio
import storage

# Kod settings.txt'ye yazabilsin diye dosya sistemini kod tarafına açar.
# Bu durumda PC'de CIRCUITPY sürücüsü SALT OKUNUR görünür.
#
# Kod dosyalarını PC'den elle kopyalamak istediğinde klavyeyi
# encoder'ın altındaki 9 numaralı tuşa (GP29) BASILI TUTARAK USB'ye tak:
# bu durumda sürücü PC'ye yazılabilir kalır.

tus = digitalio.DigitalInOut(board.GP29)
tus.switch_to_input(pull=digitalio.Pull.UP)

if tus.value:          # tuşa basılı değil
    storage.remount("/", readonly=False)

tus.deinit()
